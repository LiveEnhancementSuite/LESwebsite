/* eslint-disable no-unused-vars */
const fs = require('fs');
const { app, dialog, getCurrentWindow } = require('electron').remote;
const extract = require('extract-zip');
const exec = require('child_process').exec;
const rimraf = require('rimraf');
const os = require('os');
const axios = require('axios');
const Store = require('electron-store');
const semver = require('semver');

// eslint-disable-next-line no-undef
const button = document.getElementById('button');
// eslint-disable-next-line no-undef
const status = $('#status');

const store = new Store();

const getRepo = () => {
  if (semver.lt(os.release(), '19.0.0')) {
    return 'Inversil/LESgit';
  }
  return 'Inversil/LESgitCat';
};

const repoUri = getRepo();

let actioning = false;
let installed;
let updateAvailable = false;
let newVer;


// check for install
try {
  if (fs.existsSync('/Applications/Live Enhancement Suite.app')) {
    installed = true;
    button.firstElementChild.innerHTML = 'Uninstall';
    axios
      .get(`http://api.github.com/repos/${repoUri}/releases/latest`)
      .then((response) => {
        if (new Date(response.data.published_at) > new Date(store.get('install.date'))) {
          button.firstElementChild.innerHTML = 'Update/Uninstall';
          updateAvailable = true;
          newVer = response.data.tag_name;
        }
      });
  }
} catch (err) {
  console.error(err);
  installed = false;
}


function action() {
  if (actioning) {
    return;
  }

  if (installed && !updateAvailable) {
    const choice = dialog.showMessageBox(getCurrentWindow(),
      {
        type: 'question',
        buttons: ['Uninstall', 'Cancel'],
        title: 'Confirm',
        message: 'Are you sure you want to Uninstall?',
        detail: 'Any configuration not backed up will be lost.',
      });
    if (choice === 0) {
      uninstall();
    }
  } else if (!installed) {
    install();
  } else if (installed && updateAvailable) {
    const choice = dialog.showMessageBox(getCurrentWindow(),
      {
        type: 'question',
        buttons: [`Update to ${newVer}`, 'Uninstall', 'Cancel'],
        title: 'Confirm',
        message: `A newer version of LES is available! (${newVer})`,
        detail: 'Your configuration will be preserved if you choose to update.',
      });
    if (choice === 0) {
      install(true);
    } else if (choice === 1) {
      const removeChoice = dialog.showMessageBox(getCurrentWindow(),
        {
          type: 'question',
          buttons: ['Uninstall', 'Cancel'],
          title: 'Confirm',
          message: 'Are you sure you want to Uninstall?',
          detail: 'Any configuration not backed up will be lost.',
        });
      if (removeChoice === 0) {
        uninstall();
      }
    }
  }
}


function uninstall() {
  if (actioning) {
    return;
  }


  actioning = true;
  document.getElementById('progress').style.width = '0%';
  button.classList.remove('clickable');
  button.classList.add('loading');
  button.firstElementChild.innerHTML = 'Uninstalling...';
  status.text('Killing Hammerspoon...');
  exec('pkill Hammerspoon');
  exec('launchctl unload /Applications/Live\\ Enhancement\\ Suite.app/Contents/.Hidden/live.enhancement.suite.plist');
  document.getElementById('progress').style.width = '20%';
  status.text('Removing Binary');
  rimraf('/Applications/Live Enhancement Suite.app/', (err) => {
    if (err) {
      dialog.showErrorBox('An Error Occured', err);
      throw err;
    }
    document.getElementById('progress').style.width = '60%';
    status.text('Removing User Data');
    rimraf(`${os.homedir()}/.hammerspoon/`, (error) => {
      if (error) {
        console.log(error);
        throw error;
      }
      document.getElementById('progress').style.width = '100%';
      button.classList.add('clickable');
      button.classList.remove('loading');
      button.firstElementChild.innerHTML = 'Install';
      status.text('Successfully Uninstalled!');
      actioning = false;
      installed = false;
    });
  });
}


function install(update) {
  if (actioning) {
    return;
  }
  if (fs.existsSync('/Applications/Hammerspoon.app')) {
    const choice = dialog.showMessageBox(getCurrentWindow(),
      {
        type: 'warning',
        buttons: ['Install Anyway', 'Cancel'],
        // title: 'Hammerspoon Found',
        message: 'Hammerspoon Installation Found',
        detail: 'It looks like Hammerspoon is installed on your computer. Since les is built from a modified version of Hammerspoon, it may cause unexpected issues when both are installed in parallel.',
      });
    if (choice === 1) {
      return;
    }
  }

  axios
    .get(`http://api.github.com/repos/${repoUri}/releases/latest`)
    .then((response) => {
      console.log(response.data);
      console.log(response.data.assets[0].browser_download_url);


      actioning = true;
      document.getElementById('progress').style.width = '0%';
      button.classList.remove('clickable');
      button.classList.add('loading');
      if (update) {
        button.firstElementChild.innerHTML = 'Updating...';
      } else {
        button.firstElementChild.innerHTML = 'Installing...';
      }
      status.text('Downloading Files...');
      require('electron')
        .remote
        .require('electron-download-manager')
        .download({
          url: response.data.assets[0].browser_download_url,
          onProgress: (progress) => {
            document.getElementById('progress').style.width = `${progress}%`;
          },
        }, (error, info) => {
          if (error) {
            console.log(error);
            throw error;
          }
          status.text('Installing...');

          document.getElementById('progress').style.width = '100%';
          if (update) {
            exec('pkill Hammerspoon');
            rimraf.sync('/Applications/Live Enhancement Suite.app/');
          }
          extract(`${app.getPath('downloads')}/.les_install_cache/${response.data.assets[0].name}`, { dir: '/Applications/' }, (error) => {
            if (error) {
              console.log(error);
              throw error;
            }


            button.classList.add('clickable');
            button.classList.remove('loading');
            button.firstElementChild.innerHTML = 'Uninstall';
            actioning = false;
            installed = true;

            store.set('install.date', response.data.published_at);
            store.set('install.tag', response.data.tag_name);
            store.set('install.id', response.data.id);
            store.set('install.bundle', response.data.assets[0].name);
            rimraf.sync(`${app.getPath('downloads')}/.les_install_cache`);
            if (update) {
              updateAvailable = false;
              status.text(`Successfully updated to ${response.data.tag_name}`);
            } else {
              status.text('Done!');
            }
          });
        });
    });
}
